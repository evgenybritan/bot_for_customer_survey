#!/usr/bin/env python3

import time

import telebot
from telebot import types, apihelper

import config


bot = telebot.TeleBot(config.BOT_TOKEN)

READY_TO_ORDER = {}


@bot.message_handler(commands=['start'])
def start_command_handler(message):
	cid = message.chat.id
	uid = message.from_user.id
	READY_TO_ORDER[uid] = {}
	text = '1. Выберите тип сайта'
	markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False, row_width=1)
	for x in config.keyboards[0]:
		markup.add(x)
	return bot.send_message(cid, text, reply_markup=markup)


@bot.message_handler(content_types=['text'])
def text_content_handler(message):
	cid = message.chat.id
	uid = message.from_user.id

	if uid in READY_TO_ORDER:
		if 'type' not in READY_TO_ORDER[uid]:
			if message.text not in config.keyboards[0]:
				text = 'Выберите один из вариантов на клавиатуре'
				return bot.send_message(cid, text)
			READY_TO_ORDER[uid]['type'] = message.text
			text = '2. Выберите цветовую гамму'
			markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False, row_width=1)
			for x in config.keyboards[1]:
				markup.add(x)
			return bot.send_message(cid, text, reply_markup=markup)
		if 'gamma' not in READY_TO_ORDER[uid]:
			if message.text not in config.keyboards[1]:
				text = 'Выберите один из вариантов на клавиатуре'
				return bot.send_message(cid, text)
			READY_TO_ORDER[uid]['gamma'] = message.text
			text = '3. Нужно ли вам продвижение'
			markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False, row_width=1)
			for x in config.keyboards[2]:
				markup.add(x)
			return bot.send_message(cid, text, reply_markup=markup)
		if 'prod' not in READY_TO_ORDER[uid]:
			if message.text not in config.keyboards[2]:
				text = 'Выберите один из вариантов на клавиатуре'
				return bot.send_message(cid, text)
			READY_TO_ORDER[uid]['prod'] = message.text
			text = '4. Нужен ли вам индивидуальный дизайн'
			markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False, row_width=1)
			for x in config.keyboards[3]:
				markup.add(x)
			return bot.send_message(cid, text, reply_markup=markup)
		if 'design' not in READY_TO_ORDER[uid]:
			if message.text not in config.keyboards[3]:
				text = 'Выберите один из вариантов на клавиатуре'
				return bot.send_message(cid, text)
			READY_TO_ORDER[uid]['design'] = message.text
			text = '5. Есть ли у вас старый сайт'
			markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False, row_width=1)
			for x in config.keyboards[4]:
				markup.add(x)
			return bot.send_message(cid, text, reply_markup=markup)
		if 'old_site' not in READY_TO_ORDER[uid]:
			if message.text not in config.keyboards[4]:
				text = 'Выберите один из вариантов на клавиатуре'
				return bot.send_message(cid, text)
			READY_TO_ORDER[uid]['old_site'] = message.text
			text = '6. Есть ли у вас готовые материалы'
			markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False, row_width=1)
			for x in config.keyboards[5]:
				markup.add(x)
			return bot.send_message(cid, text, reply_markup=markup)
		if 'materials' not in READY_TO_ORDER[uid]:
			if message.text not in config.keyboards[5]:
				text = 'Выберите один из вариантов на клавиатуре'
				return bot.send_message(cid, text)
			READY_TO_ORDER[uid]['materials'] = message.text
			admin_text = 'Новая заявка!\n\nПользователь: <a href="tg://user?id={!s}">{!s}</a>\n\n'.format(
				uid, message.from_user.first_name)
			admin_text += '1) Тип сайта: {!s}\n\n2) Цветовая гамма: {!s}\n\n'.format(
				READY_TO_ORDER[uid]['type'], READY_TO_ORDER[uid]['gamma'])
			admin_text += '3) Продвижение: {!s}\n\n4) Индивидуальный дизайн: {!s}\n\n'.format(
				READY_TO_ORDER[uid]['prod'], READY_TO_ORDER[uid]['design'])
			admin_text += '5) Есть старый сайт: {!s}\n\n6) Есть готовый материалы: {!s}\n\n'.format(
				READY_TO_ORDER[uid]['old_site'], READY_TO_ORDER[uid]['materials'])
			for adm_id in config.ADMINS:
				try:
					bot.send_message(adm_id, admin_text, parse_mode='HTML')
				except Exception as e:
					print(e)
					continue
			del READY_TO_ORDER[uid]
			text = 'Спасибо за Ваши ответы, вскоре наш специалист перезвонит Вам'
			bot.send_message(cid, text)
			text = 'Что бы оставить заявку ещё раз, отправьте /start'
			markup = types.ReplyKeyboardRemove()
			return bot.send_message(cid, text, reply_markup=markup)


def main():
	if config.DEBUG:
		apihelper.proxy = config.PROXY
		bot.polling()
	else:
		while True:
			try:
				bot.polling(interval=0, none_stop=True)
			except Exception as e:
				print(e)
				time.sleep(30)
				continue


if __name__ == '__main__':
	main()
