BOT_TOKEN = '799637142:AAF8LO1UyKXTrIKNBhEQSVJiZ-pwYNU1pR0'
DEBUG = False
ADMINS = [217166737, 291288016]
PROXY = {'https': 'socks5h://vielfrass:vielfrass@vielfrassx.tk:8000'}

keyboards = [
	[
		'landing',
		'многостраничный',
		'интернет-магазин/каталог',
		'не знаю',
	],
	[
		'ч/б',
		'яркий/красочный',
		'темный (основной цвет темного оттенка + серый)',
		'не знаю/другой',
	],
	[
		'да',
		'нет',
	],
	[
		'да',
		'нет',
	],
	[
		'да',
		'нет',
	],
	[
		'да',
		'нет',
	],
]
